import { useState, useCallback, useEffect } from 'react'
import MAPTESTMap from './components/MAPTESTMap'
import Panel        from './components/Panel'
import Legend       from './components/Legend'
import Toast        from './components/Toast'
import { useRouting } from './hooks/useRouting'
import { useToast   } from './hooks/useToast'
import { USER_LOCATION } from './data/config'

export default function App() {
  // In production: replace with navigator.geolocation.watchPosition()
  const [userLocation] = useState(USER_LOCATION)

  const { activeDestId, mode, setMode, routeData, routeTo } = useRouting(userLocation)
  const { toast, showToast } = useToast()

  // Active destination object (needed for re-routing on mode change)
  const [activeDest, setActiveDest] = useState(null)

  const handleDestClick = useCallback((place) => {
    setActiveDest(place)
    routeTo(place)
    showToast(
      `Route to ${place.name}`,
      `${mode.charAt(0).toUpperCase() + mode.slice(1)} route plotted. ${place.scores[mode]}% safety score. ~${place.timeMin} min walk.`
    )
  }, [routeTo, showToast, mode])

  const handleModeChange = useCallback((newMode) => {
    setMode(newMode)
  }, [setMode])

  // Re-route when mode changes while a destination is active
  useEffect(() => {
    if (activeDest) {
      routeTo(activeDest)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode])

  const handleSOS = useCallback(() => {
    showToast(
      '🚨 SOS Activated',
      'Your location has been shared with emergency contacts and nearest police station. Help is on the way.'
    )
  }, [showToast])

  const score = routeData ? routeData.score : 64

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>
      {/* Full-screen map */}
      <MAPTESTMap
        userLocation={userLocation}
        routeData={routeData}
        onMarkerClick={handleDestClick}
      />

      {/* Left control panel */}
      <Panel
        mode={mode}
        onModeChange={handleModeChange}
        routeData={routeData}
        activeDestId={activeDestId}
        onDestClick={handleDestClick}
        onSOS={handleSOS}
        score={score}
      />

      {/* Map legend (top-right) */}
      <Legend />

      {/* Toast notifications */}
      <Toast toast={toast} />
    </div>
  )
}
