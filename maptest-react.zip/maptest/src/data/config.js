// ─────────────────────────────────────────────────────────────
//  MAP DATA  —  edit these to match your city / dataset
// ─────────────────────────────────────────────────────────────

/** Geographic center of the map */
export const MAP_CENTER = [12.9692, 79.1559];

/** Simulated user position (replace with navigator.geolocation in prod) */
export const USER_LOCATION = [12.9800, 79.1600];

/** Initial zoom level */
export const MAP_ZOOM = 14;

/**
 * Crime heatmap points.
 * Format: [lat, lng, intensity]  —  intensity: 0.0 (cool) → 1.0 (hot)
 * Source: replace with your police open-data / backend API
 */
export const CRIME_HEAT_POINTS = [
  [12.9710, 79.1580, 0.90],
  [12.9715, 79.1575, 0.85],
  [12.9705, 79.1590, 0.75],
  [12.9650, 79.1500, 0.80],
  [12.9645, 79.1510, 0.70],
  [12.9660, 79.1495, 0.65],
  [12.9750, 79.1400, 0.95],
  [12.9745, 79.1390, 0.85],
  [12.9755, 79.1410, 0.80],
  [12.9780, 79.1450, 0.50],
  [12.9730, 79.1530, 0.45],
  [12.9820, 79.1550, 0.30],
  [12.9670, 79.1620, 0.60],
  [12.9820, 79.1480, 0.40],
  [12.9700, 79.1450, 0.35],
  [12.9760, 79.1350, 0.55],
  [12.9625, 79.1480, 0.40],
  [12.9840, 79.1600, 0.25],
];

/** Danger zone boundary circles */
export const DANGER_ZONES = [
  { lat: 12.9710, lng: 79.1580, radius: 280 },
  { lat: 12.9650, lng: 79.1500, radius: 220 },
  { lat: 12.9750, lng: 79.1400, radius: 320 },
];

/**
 * Safe destinations registry.
 * scores: { safe, crowd, lit, fastest }  —  0-100 per routing mode
 */
export const SAFE_PLACES = [
  {
    id: 0,
    name: 'VIT University Main Gate',
    lat: 12.9692,
    lng: 79.1559,
    tags: ['crowd', 'police', 'light'],
    tagLabels: ['High Crowd', 'Police Post', 'Well Lit'],
    scores: { safe: 94, crowd: 96, lit: 90, fastest: 72 },
    distKm: 1.2,
    timeMin: 16,
    checks: [
      'Active security post nearby',
      '24/7 crowd density',
      'Bright street lighting',
      'CCTV coverage',
    ],
  },
  {
    id: 1,
    name: 'City Medical Hospital',
    lat: 12.9244,
    lng: 79.1353,
    tags: ['hospital', 'light', 'police'],
    tagLabels: ['Hospital Zone', 'Lit Campus', 'Patrol Route'],
    scores: { safe: 89, crowd: 70, lit: 92, fastest: 60 },
    distKm: 2.8,
    timeMin: 38,
    checks: [
      'Emergency services on site',
      'Patrol vehicle route',
      'Bright campus lighting',
      '24hr activity',
    ],
  },
  {
    id: 2,
    name: 'Central Bus Terminal',
    lat: 12.9723,
    lng: 79.1378,
    tags: ['crowd', 'light'],
    tagLabels: ['Busy Hub', 'Street Lights'],
    scores: { safe: 78, crowd: 92, lit: 80, fastest: 88 },
    distKm: 1.9,
    timeMin: 24,
    checks: [
      'High pedestrian traffic',
      'Public area surveillance',
      'Regular bus activity',
      'Vendor presence',
    ],
  },
  {
    id: 3,
    name: 'Police Station',
    lat: 12.9760,
    lng: 79.1500,
    tags: ['police', 'light'],
    tagLabels: ['Police HQ', '24hr Lit'],
    scores: { safe: 98, crowd: 55, lit: 95, fastest: 50 },
    distKm: 2.1,
    timeMin: 28,
    checks: [
      'Direct police protection',
      'Immediate emergency response',
      'Constant lighting',
      'Secure perimeter',
    ],
  },
];

/** Routing mode definitions */
export const ROUTE_MODES = [
  { id: 'safe',    icon: '🛡', label: 'Safest' },
  { id: 'crowd',   icon: '👥', label: 'Crowded' },
  { id: 'lit',     icon: '💡', label: 'Well Lit' },
  { id: 'fastest', icon: '⚡', label: 'Fastest' },
];

/** Per-mode route colour */
export const MODE_COLORS = {
  safe:    '#00ff87',
  crowd:   '#00c9ff',
  lit:     '#ffaa00',
  fastest: '#a78bfa',
};

/** Per-mode safety checks shown in the result panel */
export const MODE_CHECKS = {
  safe:    ['Avoids all high-risk zones', 'Circumvents dark alleys', 'Stays on patrolled streets'],
  crowd:   ['Maximum pedestrian presence', 'Busy commercial zones', 'Public transport corridors'],
  lit:     ['Prioritises street lights', 'Avoids unlit stretches', 'Commercial area coverage'],
  fastest: ['Direct path selected', 'Some risk zones bypassed', 'Shortest available path'],
};

/** Heatmap gradient */
export const HEAT_GRADIENT = {
  0.0:  '#000033',
  0.2:  '#0000ff',
  0.4:  '#ffaa00',
  0.6:  '#ff4400',
  0.85: '#ff0000',
  1.0:  '#ff003c',
};
