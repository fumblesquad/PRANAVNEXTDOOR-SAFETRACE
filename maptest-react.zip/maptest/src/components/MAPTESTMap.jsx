import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet'

// leaflet.heat is a UMD plugin — import side-effects only
import 'leaflet.heat'

import {
  MAP_CENTER, MAP_ZOOM,
  CRIME_HEAT_POINTS, DANGER_ZONES, SAFE_PLACES,
  HEAT_GRADIENT,
} from '../data/config'

export default function MAPTESTMap({ userLocation, routeData, onMarkerClick }) {
  const containerRef  = useRef(null)
  const mapRef        = useRef(null)
  const routeLayerRef = useRef([])

  // ── Initialise map once ───────────────────────────────────
  useEffect(() => {
    if (mapRef.current) return

    const map = L.map(containerRef.current, {
      center: MAP_CENTER,
      zoom: MAP_ZOOM,
      zoomControl: false,
      attributionControl: true,
    })
    mapRef.current = map

    // OSM base tiles (dark-filtered via CSS)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a>',
    }).addTo(map)

    // Crime heatmap layer
    L.heatLayer(CRIME_HEAT_POINTS, {
      radius: 40,
      blur: 30,
      maxZoom: 16,
      gradient: HEAT_GRADIENT,
    }).addTo(map)

    // Danger zone circles
    DANGER_ZONES.forEach(({ lat, lng, radius }) => {
      L.circle([lat, lng], {
        radius,
        color: '#ff3b5c',
        fillColor: '#ff3b5c',
        fillOpacity: 0.08,
        weight: 1.5,
        dashArray: '6,4',
        opacity: 0.5,
      }).addTo(map)
    })

    // User location marker
    if (userLocation) {
      const userIcon = L.divIcon({
        className: '',
        html: '<div class="user-marker"></div>',
        iconSize: [16, 16],
        iconAnchor: [8, 8],
      })
      L.marker(userLocation, { icon: userIcon })
        .addTo(map)
        .bindPopup('<b style="color:#00c9ff">📍 Your Location</b><br><small>Real-time tracking active</small>')
    }

    // Safe destination markers
    SAFE_PLACES.forEach((place) => {
      const icon = L.divIcon({
        className: '',
        html: '<div class="safe-marker"></div>',
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      })
      L.marker([place.lat, place.lng], { icon })
        .addTo(map)
        .bindPopup(
          `<b style="color:#00ff87">${place.name}</b><br><small>Safety: ${place.scores.safe}%</small>`
        )
        .on('click', () => onMarkerClick(place))
    })

    return () => {
      map.remove()
      mapRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ── Update route polylines when routeData changes ─────────
  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    // Remove previous route layers
    routeLayerRef.current.forEach(l => map.removeLayer(l))
    routeLayerRef.current = []

    if (!routeData) return

    const { safeWaypoints, riskyWaypoints, color, dest } = routeData

    // Dashed red = risky shortcut
    const riskyLine = L.polyline(riskyWaypoints, {
      color: '#ff3b5c',
      weight: 3,
      opacity: 0.45,
      dashArray: '8,6',
    }).addTo(map)

    // Solid safe route
    const safeLine = L.polyline(safeWaypoints, {
      color,
      weight: 5,
      opacity: 0.9,
    }).addTo(map)

    routeLayerRef.current = [riskyLine, safeLine]

    // Fit bounds
    const bounds = L.latLngBounds([...safeWaypoints, [dest.lat, dest.lng]])
    map.fitBounds(bounds, { padding: [80, 80], maxZoom: 15 })
  }, [routeData])

  return (
    <div
      ref={containerRef}
      className="map-scanline"
      style={{ position: 'absolute', inset: 0, zIndex: 1 }}
    />
  )
}
