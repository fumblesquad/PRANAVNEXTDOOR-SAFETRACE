import { useState } from 'react'
import { SAFE_PLACES, ROUTE_MODES } from '../data/config'
import DestCard from './DestCard'
import RouteResult from './RouteResult'

const styles = {
  panel: {
    position: 'absolute', top: 0, left: 0, bottom: 0, width: 320, zIndex: 10,
    background: 'rgba(10,12,16,0.93)',
    borderRight: '1px solid var(--border)',
    backdropFilter: 'blur(20px)',
    display: 'flex', flexDirection: 'column',
    overflow: 'hidden',
  },
  header: {
    padding: '20px 24px 16px',
    borderBottom: '1px solid var(--border)',
    position: 'relative',
  },
  headerStripe: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
    background: 'linear-gradient(90deg, var(--accent), var(--accent2))',
  },
  logo: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 },
  logoIcon: {
    width: 32, height: 32,
    background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
    borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
  },
  logoText: {
    fontSize: 20, fontWeight: 800, letterSpacing: '-0.5px',
    background: 'linear-gradient(90deg, var(--accent), var(--accent2))',
    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
  },
  logoSub: { fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--muted)', letterSpacing: 2, textTransform: 'uppercase' },
  statusBar: { display: 'flex', gap: 8 },
  pillLive: {
    fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: 1, padding: '3px 8px',
    borderRadius: 20, textTransform: 'uppercase',
    background: 'rgba(0,255,135,0.1)', color: 'var(--accent)', border: '1px solid rgba(0,255,135,0.3)',
  },
  pillArea: {
    fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: 1, padding: '3px 8px',
    borderRadius: 20, textTransform: 'uppercase',
    background: 'rgba(0,201,255,0.1)', color: 'var(--accent2)', border: '1px solid rgba(0,201,255,0.2)',
  },
  metrics: {
    display: 'grid', gridTemplateColumns: '1fr 1fr',
    gap: 1, background: 'var(--border)',
    borderBottom: '1px solid var(--border)',
  },
  metric: { background: 'var(--panel)', padding: '14px 16px' },
  metricLabel: { fontFamily: 'var(--font-mono)', fontSize: 8, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 4 },
  metricSub: { fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--muted)', marginTop: 2 },
  safetyBarWrap: { padding: '12px 16px', borderBottom: '1px solid var(--border)' },
  safetyBarLabel: { fontFamily: 'var(--font-mono)', fontSize: 8, letterSpacing: 2, color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 6, display: 'flex', justifyContent: 'space-between' },
  safetyBarTrack: { height: 6, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' },
  modeSection: { padding: 16, borderBottom: '1px solid var(--border)' },
  sectionTitle: { fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 10 },
  modeRow: { display: 'flex', gap: 6 },
  destinations: { flex: 1, overflowY: 'auto', padding: 16 },
  sos: {
    margin: '0 16px 16px',
    background: 'linear-gradient(135deg, #ff1a3a, #ff3b5c)',
    border: 'none', borderRadius: 10, padding: 14,
    color: 'white', fontFamily: 'var(--font-display)', fontWeight: 800,
    fontSize: 14, letterSpacing: 1, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    boxShadow: '0 0 20px rgba(255,59,92,0.2)',
    transition: 'all 0.2s',
  },
}

export default function Panel({ mode, onModeChange, routeData, activeDestId, onDestClick, onSOS, score }) {
  const [sosActive, setSosActive] = useState(false)

  function handleSOS() {
    setSosActive(true)
    onSOS()
    setTimeout(() => setSosActive(false), 4000)
  }

  return (
    <div style={styles.panel}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerStripe} />
        <div style={styles.logo}>
          <div style={styles.logoIcon}>🛡</div>
          <div>
            <div style={styles.logoText}>MAPTEST</div>
            <div style={styles.logoSub}>Intelligent Safety Routing</div>
          </div>
        </div>
        <div style={styles.statusBar}>
          <span style={styles.pillLive}>● Live</span>
          <span style={styles.pillArea}>Vellore, TN</span>
        </div>
      </div>

      {/* Metrics grid */}
      <div style={styles.metrics}>
        {[
          { label: 'Area Status', value: 'CAUTION', color: 'var(--warn)', sub: '3 active zones' },
          { label: 'Safety Index', value: `${score}/100`, color: 'var(--text)', sub: 'Updated now' },
          { label: 'Crowd Level', value: 'MED', color: 'var(--accent)', sub: 'Moderate traffic' },
          { label: 'Lighting',    value: 'LOW', color: 'var(--warn)',   sub: 'Night conditions' },
        ].map((m) => (
          <div key={m.label} style={styles.metric}>
            <div style={styles.metricLabel}>{m.label}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: m.color, lineHeight: 1 }}>{m.value}</div>
            <div style={styles.metricSub}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* Safety bar */}
      <div style={styles.safetyBarWrap}>
        <div style={styles.safetyBarLabel}>
          <span>Route Safety Score</span>
          <span>{routeData ? routeData.score : score}%</span>
        </div>
        <div style={styles.safetyBarTrack}>
          <div style={{
            height: '100%', borderRadius: 3,
            background: 'linear-gradient(90deg, var(--danger), var(--warn) 50%, var(--accent))',
            width: `${routeData ? routeData.score : score}%`,
            transition: 'width 0.5s',
          }} />
        </div>
      </div>

      {/* Routing modes */}
      <div style={styles.modeSection}>
        <div style={styles.sectionTitle}>Routing Priority</div>
        <div style={styles.modeRow}>
          {ROUTE_MODES.map((m) => (
            <ModeButton key={m.id} mode={m} active={mode === m.id} onClick={() => onModeChange(m.id)} />
          ))}
        </div>
      </div>

      {/* Destinations */}
      <div style={{ padding: '0 16px 8px', ...styles.sectionTitle }}>Safe Destinations</div>
      <div style={styles.destinations}>
        {SAFE_PLACES.map((place) => (
          <DestCard
            key={place.id}
            place={place}
            mode={mode}
            active={activeDestId === place.id}
            onClick={() => onDestClick(place)}
          />
        ))}
      </div>

      {/* Route result */}
      {routeData && <RouteResult routeData={routeData} />}

      {/* SOS */}
      <button
        style={{
          ...styles.sos,
          boxShadow: sosActive ? undefined : '0 0 20px rgba(255,59,92,0.2)',
          animation: sosActive ? 'sos-pulse 0.6s infinite' : 'none',
        }}
        onClick={handleSOS}
      >
        🆘 {sosActive ? 'BROADCASTING LOCATION...' : 'EMERGENCY SOS'}
      </button>
    </div>
  )
}

function ModeButton({ mode, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1,
        background: active ? 'rgba(0,255,135,0.08)' : 'var(--border)',
        border: `1px solid ${active ? 'var(--accent)' : 'transparent'}`,
        color: active ? 'var(--accent)' : 'var(--muted)',
        fontFamily: 'var(--font-mono)',
        fontSize: 8, letterSpacing: 1, textTransform: 'uppercase',
        padding: '8px 6px', borderRadius: 8, cursor: 'pointer',
        transition: 'all 0.2s', textAlign: 'center',
      }}
    >
      <div style={{ fontSize: 14, marginBottom: 3 }}>{mode.icon}</div>
      {mode.label}
    </button>
  )
}
